"""
MiniTorch Lite - Backends Module
================================
Este módulo proporciona una capa de abstracción para diferentes backends de cálculo numérico.
Permite cambiar entre NumPy, Numba, JAX y CuPy según disponibilidad y preferencia del usuario.
"""

import numpy as np
from typing import Optional, Callable, Any
import warnings

# --- Estado Global del Backend ---
_CURRENT_BACKEND = "numpy"
_AVAILABLE_BACKENDS = ["numpy"]

# --- Detección de Backends Disponibles ---
try:
    import numba
    from numba import jit, njit, vectorize, guvectorize, prange
    _AVAILABLE_BACKENDS.append("numba")
    HAS_NUMBA = True
except ImportError:
    HAS_NUMBA = False
    numba = None

try:
    import jax
    import jax.numpy as jnp
    from jax import grad, jit as jax_jit, vmap
    _AVAILABLE_BACKENDS.append("jax")
    HAS_JAX = True
except ImportError:
    HAS_JAX = False
    jax = None
    jnp = None

try:
    import cupy as cp
    _AVAILABLE_BACKENDS.append("cupy")
    HAS_CUPY = True
except ImportError:
    HAS_CUPY = False
    cp = None

try:
    import scipy
    from scipy import optimize, linalg
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False
    scipy = None

# --- Funciones de Configuración de Backend ---

def set_backend(backend: str) -> None:
    """
    Establece el backend de cálculo numérico.
    
    Args:
        backend: Nombre del backend (\'numpy\', \'numba\', \'jax\', \'cupy\')
    
    Raises:
        ValueError: Si el backend no está disponible.
    """
    global _CURRENT_BACKEND
    backend = backend.lower()
    
    if backend not in _AVAILABLE_BACKENDS:
        available = ", ".join(_AVAILABLE_BACKENDS)
        raise ValueError(f"Backend \'{backend}\' no disponible. Backends disponibles: {available}")
    
    _CURRENT_BACKEND = backend
    print(f"[MiniTorch Lite] Backend establecido: {backend}")

def get_backend() -> str:
    """Retorna el nombre del backend actual."""
    return _CURRENT_BACKEND

def get_available_backends() -> list:
    """Retorna la lista de backends disponibles."""
    return _AVAILABLE_BACKENDS.copy()

# --- Funciones de Operaciones Matemáticas con Backend Dinámico ---

def matmul(a, b):
    """Multiplicación de matrices usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.matmul(a, b)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        # Numba usa NumPy internamente para matmul
        return np.matmul(a, b)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.matmul(a, b)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.matmul(cp.asarray(a), cp.asarray(b)).get()
    else:
        return np.matmul(a, b)

def multiply(a, b):
    """Multiplicación elemento a elemento usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.multiply(a, b)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.multiply(a, b)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.multiply(a, b)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.multiply(cp.asarray(a), cp.asarray(b)).get()
    else:
        return np.multiply(a, b)

def add(a, b):
    """Suma elemento a elemento usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.add(a, b)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.add(a, b)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.add(a, b)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.add(cp.asarray(a), cp.asarray(b)).get()
    else:
        return np.add(a, b)

def transpose(a):
    """Transpuesta de una matriz usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.transpose(a)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.transpose(a)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.transpose(a)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.transpose(cp.asarray(a)).get()
    else:
        return np.transpose(a)

def sum_array(a, axis=None, keepdims=False):
    """Suma de elementos de un array usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.sum(a, axis=axis, keepdims=keepdims)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.sum(a, axis=axis, keepdims=keepdims)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.sum(a, axis=axis, keepdims=keepdims)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.sum(cp.asarray(a), axis=axis, keepdims=keepdims).get()
    else:
        return np.sum(a, axis=axis, keepdims=keepdims)

def zeros(shape, dtype=np.float32):
    """Crea un array de ceros usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.zeros(shape, dtype=dtype)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.zeros(shape, dtype=dtype)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.zeros(shape, dtype=dtype)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.zeros(shape, dtype=dtype).get()
    else:
        return np.zeros(shape, dtype=dtype)

def ones(shape, dtype=np.float32):
    """Crea un array de unos usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.ones(shape, dtype=dtype)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.ones(shape, dtype=dtype)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.ones(shape, dtype=dtype)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.ones(shape, dtype=dtype).get()
    else:
        return np.ones(shape, dtype=dtype)

def full(shape, fill_value, dtype=np.float32):
    """Crea un array lleno de un valor usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.full(shape, fill_value, dtype=dtype)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.full(shape, fill_value, dtype=dtype)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.full(shape, fill_value, dtype=dtype)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.full(shape, fill_value, dtype=dtype).get()
    else:
        return np.full(shape, fill_value, dtype=dtype)

def array(data, dtype=np.float32):
    """Crea un array usando el backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return np.array(data, dtype=dtype)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.array(data, dtype=dtype)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.array(data, dtype=dtype)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.array(data, dtype=dtype).get()
    else:
        return np.array(data, dtype=dtype)

def ones_like(a):
    """Crea un array de unos con la misma forma que otro array."""
    if _CURRENT_BACKEND == "numpy":
        return np.ones_like(a)
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return np.ones_like(a)
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.ones_like(a)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.ones_like(cp.asarray(a)).get()
    else:
        return np.ones_like(a)

def to_numpy(a):
    """Convierte un array del backend actual a un array de NumPy."""
    if _CURRENT_BACKEND == "numpy":
        return a
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return a
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return np.asarray(a)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.asnumpy(a)
    else:
        return a

def from_numpy(a):
    """Convierte un array de NumPy a un array del backend actual."""
    if _CURRENT_BACKEND == "numpy":
        return a
    elif _CURRENT_BACKEND == "numba" and HAS_NUMBA:
        return a
    elif _CURRENT_BACKEND == "jax" and HAS_JAX:
        return jnp.asarray(a)
    elif _CURRENT_BACKEND == "cupy" and HAS_CUPY:
        return cp.asarray(a)
    else:
        return a

# --- Decoradores de Aceleración con Numba ---

def accelerate(func: Callable) -> Callable:
    """
    Decorador que acelera una función usando Numba si está disponible.
    Si Numba no está disponible, devuelve la función original.
    
    Uso:
        @accelerate
        def mi_funcion(a, b):
            return a + b
    """
    if HAS_NUMBA:
        try:
            return numba.njit(func)
        except Exception:
            warnings.warn(f"No se pudo compilar \'{func.__name__}\' con Numba. Usando versión Python.")
            return func
    else:
        return func

def parallel_accelerate(func: Callable) -> Callable:
    """
    Decorador que acelera una función usando Numba con paralelización.
    Si Numba no está disponible, devuelve la función original.
    """
    if HAS_NUMBA:
        try:
            return numba.njit(parallel=True)(func)
        except Exception:
            warnings.warn(f"No se pudo compilar \'{func.__name__}\' con Numba paralelo. Usando versión Python.")
            return func
    else:
        return func

# --- Información del Sistema ---

def print_backend_info():
    """Imprime información sobre los backends disponibles."""
    print("=" * 60)
    print("MiniTorch Lite - Información de Backends")
    print("=" * 60)
    print(f"Backend actual: {_CURRENT_BACKEND}")
    print(f"Backends disponibles: {', '.join(_AVAILABLE_BACKENDS)}")
    print("-" * 60)
    print(f"NumPy: v{np.__version__}")
    if HAS_NUMBA:
        print(f"Numba: v{numba.__version__} (JIT compilation disponible)")
    else:
        print("Numba: No instalado (pip install numba)")
    if HAS_JAX:
        print(f"JAX: v{jax.__version__} (Autograd y XLA disponibles)")
    else:
        print("JAX: No instalado (pip install jax jaxlib)")
    if HAS_CUPY:
        print(f"CuPy: v{cp.__version__} (GPU acceleration disponible)")
    else:
        print("CuPy: No instalado (pip install cupy)")
    if HAS_SCIPY:
        print(f"SciPy: v{scipy.__version__} (Optimización avanzada disponible)")
    else:
        print("SciPy: No instalado (pip install scipy)")
    print("=" * 60)
