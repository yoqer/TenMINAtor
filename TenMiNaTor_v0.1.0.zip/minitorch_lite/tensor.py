
import numpy as np
from . import backends as B
from .autograd import Function, backward
from .autograd import Add, Mul, MatMul, Sum

UFUNC_MAP = {
    np.add: Add,
    np.multiply: Mul,
}

class Tensor:
    def __init__(self, data, dtype=None, requires_grad=False, grad_fn=None):
        if isinstance(data, Tensor):
            self.data = data.data.copy()
            self.dtype = data.dtype
            self.requires_grad = data.requires_grad
            self.grad_fn = data.grad_fn
        else:
            self.data = B.array(data, dtype=dtype if dtype is not None else np.float32)
            self.dtype = self.data.dtype
            self.requires_grad = requires_grad
            self.grad_fn = grad_fn

        self.grad = None

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        if method == '__call__' and ufunc in UFUNC_MAP:
            autograd_fn = UFUNC_MAP[ufunc]
            tensor_inputs = []
            for x in inputs:
                if not isinstance(x, Tensor):
                    tensor_inputs.append(Tensor(x, requires_grad=False, dtype=self.dtype))
                else:
                    tensor_inputs.append(x)
            
            output_data, grad_fn = autograd_fn.apply(*tensor_inputs)
            return Tensor(output_data, requires_grad=any(t.requires_grad for t in tensor_inputs), grad_fn=grad_fn)
        else:
            return NotImplemented

    @property
    def shape(self):
        return self.data.shape

    @property
    def ndim(self):
        return self.data.ndim

    def __repr__(self):
        return f"Tensor({self.data}, requires_grad={self.requires_grad})"

    def __add__(self, other):
        return np.add(self, other)

    def __radd__(self, other):
        return np.add(other, self)

    def __mul__(self, other):
        return np.multiply(self, other)

    def __rmul__(self, other):
        return np.multiply(other, self)

    def __matmul__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other, requires_grad=False, dtype=self.dtype)
        output_data, grad_fn = MatMul.apply(self, other)
        return Tensor(output_data, requires_grad=self.requires_grad or other.requires_grad, grad_fn=grad_fn)

    def sum(self, axis=None, keepdims=False):
        output_data, grad_fn = Sum.apply(self, axis=axis, keepdims=keepdims)
        return Tensor(output_data, requires_grad=self.requires_grad, grad_fn=grad_fn)

    def backward(self):
        backward(self)

    def astype(self, dtype):
        return Tensor(B.astype(self.data, dtype), requires_grad=self.requires_grad, dtype=dtype)

    def to_numpy(self):
        return B.to_numpy(self.data)

    def reshape(self, *shape):
        return Tensor(B.reshape(self.data, shape), requires_grad=False, dtype=self.dtype)

    def transpose(self, *axes):
        return Tensor(B.transpose(self.data, axes), requires_grad=False, dtype=self.dtype)

    def item(self):
        return self.data.item()

    def zero_grad(self):
        self.grad = None


if __name__ == '__main__':
    print("\n--- Prueba de TenMiNaTor Autograd con Refactorización Final ---")

    a = Tensor([1., 2.], requires_grad=True)
    b = Tensor([3., 4.], requires_grad=True)
    c = a + b
    c.sum().backward()
    assert np.allclose(a.grad, [1., 1.])
    assert np.allclose(b.grad, [1., 1.])
    print("Suma: OK")

    a = Tensor([2., 3.], requires_grad=True)
    b = Tensor([4., 5.], requires_grad=True)
    c = a * b
    c.sum().backward()
    assert np.allclose(a.grad, [4., 5.])
    assert np.allclose(b.grad, [2., 3.])
    print("Multiplicación: OK")

    a = Tensor([[1., 2.], [3., 4.]], requires_grad=True)
    b = Tensor([[5., 6.], [7., 8.]], requires_grad=True)
    c = a @ b
    c.sum().backward()
    assert np.allclose(a.grad, [[11., 15.], [11., 15.]])
    assert np.allclose(b.grad, [[4., 4.], [6., 6.]])
    print("MatMul: OK")

    a = Tensor(2.0, requires_grad=True)
    b = Tensor(3.0, requires_grad=True)
    c = a * b
    d = c + a
    d.backward()
    assert a.grad == 4.0
    assert b.grad == 2.0
    print("Cadena de operaciones: OK")

    print("\n--- Todas las pruebas de autograd pasaron exitosamente ---")

