
import pandas as pd
import sqlite3
import pymongo
import requests
from bs4 import BeautifulSoup
import networkx as nx
from sqlalchemy import create_engine, text
import firebase_admin
from firebase_admin import credentials, firestore
from typing import Optional, List, Dict, Any

# --- Carga de Datos SQL (con SQLAlchemy) ---

def from_sql(query: str, connection_string: str) -> pd.DataFrame:
    """Carga datos desde cualquier base de datos SQL soportada por SQLAlchemy."""
    engine = create_engine(connection_string)
    with engine.connect() as connection:
        return pd.read_sql_query(text(query), connection)

# --- Carga de Datos NoSQL ---

def from_mongodb(query: dict, db_name: str, collection_name: str, mongo_uri: str = "mongodb://localhost:27017/") -> pd.DataFrame:
    """Carga datos desde una base de datos MongoDB."""
    client = pymongo.MongoClient(mongo_uri)
    db = client[db_name]
    collection = db[collection_name]
    cursor = collection.find(query)
    df = pd.DataFrame(list(cursor))
    client.close()
    return df

def from_firestore(collection_name: str, cred_path: str) -> pd.DataFrame:
    """Carga datos desde una colección de Firestore."""
    if not firebase_admin._apps:
        cred = credentials.Certificate(cred_path)
        firebase_admin.initialize_app(cred)
    db = firestore.client()
    docs = db.collection(collection_name).stream()
    data = [doc.to_dict() for doc in docs]
    return pd.DataFrame(data)

# --- Carga de Datos Web ---

def from_web(url: str) -> BeautifulSoup:
    """Extrae el contenido de una página web."""
    response = requests.get(url)
    response.raise_for_status()
    return BeautifulSoup(response.text, 'html.parser')

# --- Construcción de Grafos ---

def build_graph_from_web(start_url: str, max_depth: int = 1) -> nx.DiGraph:
    """Construye un grafo de enlaces a partir de una URL inicial."""
    G = nx.DiGraph()
    visited = set()
    queue = [(start_url, 0)]

    while queue:
        url, depth = queue.pop(0)
        if url in visited or depth > max_depth:
            continue

        visited.add(url)
        G.add_node(url)

        try:
            soup = from_web(url)
            for link in soup.find_all('a', href=True):
                href = link['href']
                if href.startswith('http'):
                    G.add_edge(url, href)
                    if href not in visited:
                        queue.append((href, depth + 1))
        except requests.exceptions.RequestException as e:
            print(f"Error al acceder a {url}: {e}")

    return G

# --- Limpieza de Datos ---

def handle_missing_values(df: pd.DataFrame, strategy: str = 'mean') -> pd.DataFrame:
    """Maneja valores faltantes en un DataFrame."""
    if strategy == 'mean':
        return df.fillna(df.mean())
    elif strategy == 'median':
        return df.fillna(df.median())
    elif strategy == 'mode':
        return df.fillna(df.mode().iloc[0])
    elif strategy == 'drop':
        return df.dropna()
    else:
        raise ValueError(f"Estrategia no soportada: {strategy}")

def normalize_data(df: pd.DataFrame) -> pd.DataFrame:
    """Normaliza los datos numéricos en un DataFrame (escala 0-1)."""
    numeric_cols = df.select_dtypes(include=['number']).columns
    df[numeric_cols] = (df[numeric_cols] - df[numeric_cols].min()) / (df[numeric_cols].max() - df[numeric_cols].min())
    return df

# --- Ejemplo de Uso ---

def example_database_connections():
    """Ejemplo de conexiones a diferentes bases de datos."""
    # Ejemplo con SQLite (usando SQLAlchemy)
    print("--- Conexión a SQLite con SQLAlchemy ---")
    # Crear una base de datos de ejemplo
    conn = sqlite3.connect("example.db")
    pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]}).to_sql('test_table', conn, if_exists='replace', index=False)
    conn.close()
    # Leer desde la base de datos
    df_sql = from_sql("SELECT * FROM test_table", "sqlite:///example.db")
    print(df_sql)

    # Nota: Los siguientes ejemplos requieren configuración externa (servidores de BD, credenciales)
    # y no se ejecutarán en el sandbox.

    # Ejemplo con MariaDB (usando SQLAlchemy)
    # print("\n--- Conexión a MariaDB con SQLAlchemy ---")
    # mariadb_conn_str = "mysql+pymysql://user:password@host/db"
    # df_mariadb = from_sql("SELECT * FROM your_table", mariadb_conn_str)
    # print(df_mariadb)

    # Ejemplo con MongoDB
    # print("\n--- Conexión a MongoDB ---")
    # df_mongo = from_mongodb({}, 'your_db', 'your_collection')
    # print(df_mongo)

    # Ejemplo con Firestore
    # print("\n--- Conexión a Firestore ---")
    # df_firestore = from_firestore('your_collection', 'path/to/your/credentials.json')
    # print(df_firestore)

if __name__ == "__main__":
    example_database_connections()

