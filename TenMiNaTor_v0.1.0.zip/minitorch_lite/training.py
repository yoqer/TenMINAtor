
import time
import json
import os
from dataclasses import dataclass, asdict
import pickle
from pathlib import Path
from typing import Optional, Dict, Any, Callable, List
from dataclasses import dataclass, field
from datetime import datetime
import warnings

@dataclass
class TrainingConfig:
    """
    Configuración del entrenamiento con opciones de control.
    
    Opciones disponibles:
    - max_iterations: Máximo de iteraciones (por defecto 69)
    - early_stop_patience: Número de iteraciones sin mejora antes de parar (por defecto 12) [NEW]
    - max_tokens: Límite de tokens por iteración (por defecto None, sin límite)
    - token_limit_iterations: Máximo de iteraciones con límite de tokens (por defecto 12)
    - save_checkpoint_on_stop: Guardar punto de control al detenerse
    - checkpoint_dir: Directorio para guardar puntos de control
    """
    max_iterations: int = 69
    early_stop_patience: int = 12  # [NEW] Salto tras 12 iteraciones sin mejora
    max_tokens: Optional[int] = None  # Límite de tokens (None = sin límite)
    token_limit_iterations: int = 12  # Máximo de iteraciones con límite de tokens
    save_checkpoint_on_stop: bool = True
    checkpoint_dir: str = "./checkpoints"
    
    # Opciones avanzadas
    min_delta: float = 1e-6  # Mínima mejora para considerar progreso
    verbose: bool = True
    log_interval: int = 10  # Intervalo de logging
    
    # Opciones de continuación
    resume_from_checkpoint: Optional[str] = None
    
    def __post_init__(self):
        Path(self.checkpoint_dir).mkdir(parents=True, exist_ok=True)

@dataclass
class TrainingState:
    """
    Estado del entrenamiento para guardado y reanudación.
    """
    current_iteration: int = 0
    best_loss: float = float("inf")
    iterations_without_improvement: int = 0
    total_tokens_processed: int = 0
    loss_history: List[float] = field(default_factory=list)
    gradient_history: List[float] = field(default_factory=list)
    
    # Metadatos
    start_time: str = ""
    last_update_time: str = ""
    stop_reason: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "current_iteration": self.current_iteration,
            "best_loss": self.best_loss,
            "iterations_without_improvement": self.iterations_without_improvement,
            "total_tokens_processed": self.total_tokens_processed,
            "loss_history": self.loss_history,
            "gradient_history": self.gradient_history,
            "start_time": self.start_time,
            "last_update_time": self.last_update_time,
            "stop_reason": self.stop_reason
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrainingState":
        return cls(**data)

class TrainingController:
    """
    Controlador de entrenamiento con opciones de Early Stopping y límite de iteraciones.
    
    Opciones seleccionables:
    1. [NEW] early_stop: Salto tras 12 iteraciones repetitivas sin mejora
    2. token_limit: Corte automático a N tokens con máximo 12 iteraciones
    3. Por defecto: Máximo 69 repeticiones
    
    Uso:
        controller = TrainingController(config)
        
        for data in dataloader:
            if not controller.should_continue():
                break
            
            loss = train_step(data)
            controller.update(loss)
        
        controller.save_checkpoint(model, optimizer)
    """
    
    def __init__(self, model, optimizer, loss_fn, config: Optional[TrainingConfig] = None, early_stop_patience: int = 12):
        self.config = config or TrainingConfig()
        self.state = TrainingState()
        self.state.start_time = datetime.now().isoformat()
        
        # Cargar checkpoint si se especifica
        if self.config.resume_from_checkpoint:
            self.load_checkpoint(self.config.resume_from_checkpoint)
    
    def should_continue(self) -> bool:
        """
        Determina si el entrenamiento debe continuar.
        
        Retorna False si:
        - Se alcanzó el máximo de iteraciones (69 por defecto)
        - Se alcanzó el límite de iteraciones sin mejora (12) [NEW]
        - Se alcanzó el límite de tokens
        """
        # Verificar máximo de iteraciones
        if self.state.current_iteration >= self.config.max_iterations:
            self.state.stop_reason = f"Máximo de iteraciones alcanzado ({self.config.max_iterations})"
            return False
        
        # [NEW] Verificar Early Stopping (12 iteraciones sin mejora)
        if self.state.iterations_without_improvement >= self.config.early_stop_patience:
            self.state.stop_reason = f"[NEW] Early Stop: {self.config.early_stop_patience} iteraciones sin mejora"
            return False
        
        # Verificar límite de tokens
        if self.config.max_tokens is not None:
            if self.state.total_tokens_processed >= self.config.max_tokens:
                if self.state.current_iteration >= self.config.token_limit_iterations:
                    self.state.stop_reason = f"Límite de tokens alcanzado ({self.config.max_tokens})"
                    return False
        
        return True
    
    def update(self, loss: float, tokens_processed: int = 0, gradient_norm: Optional[float] = None):
        """
        Actualiza el estado del entrenamiento con la pérdida actual.
        
        Args:
            loss: Valor de la pérdida en la iteración actual
            tokens_processed: Número de tokens procesados en esta iteración
            gradient_norm: Norma del gradiente (opcional, para logging)
        """
        self.state.current_iteration += 1
        self.state.total_tokens_processed += tokens_processed
        self.state.loss_history.append(loss)
        self.state.last_update_time = datetime.now().isoformat()
        
        if gradient_norm is not None:
            self.state.gradient_history.append(gradient_norm)
        
        # Verificar mejora
        if loss < self.state.best_loss - self.config.min_delta:
            self.state.best_loss = loss
            self.state.iterations_without_improvement = 0
        else:
            self.state.iterations_without_improvement += 1
        
        # Logging
        if self.config.verbose and self.state.current_iteration % self.config.log_interval == 0:
            self._log_progress()
    
    def _log_progress(self):
        """Imprime el progreso del entrenamiento."""
        print(f"[Iter {self.state.current_iteration}/{self.config.max_iterations}] "
              f"Loss: {self.state.loss_history[-1]:.6f} | "
              f"Best: {self.state.best_loss:.6f} | "
              f"Sin mejora: {self.state.iterations_without_improvement}/{self.config.early_stop_patience}")
    
    def save_checkpoint(self, model_state: Dict[str, Any], optimizer_state: Optional[Dict[str, Any]] = None,
                       filepath: Optional[str] = None) -> str:
        """
        Guarda un punto de control del entrenamiento.
        
        Args:
            model_state: Estado del modelo (pesos)
            optimizer_state: Estado del optimizador (opcional)
            filepath: Ruta del archivo (opcional, se genera automáticamente)
        
        Returns:
            Ruta del archivo guardado
        """
        if filepath is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = Path(self.config.checkpoint_dir) / f"checkpoint_{timestamp}.pkl"
        
        checkpoint = {
            "training_state": self.state.to_dict(),
            "config": {
                "max_iterations": self.config.max_iterations,
                "early_stop_patience": self.config.early_stop_patience,
                "max_tokens": self.config.max_tokens,
                "token_limit_iterations": self.config.token_limit_iterations
            },
            "model_state": model_state,
            "optimizer_state": optimizer_state
        }
        
        with open(filepath, "wb") as f:
            pickle.dump(checkpoint, f)
        
        print(f"[TenMiNaTor] Checkpoint guardado: {filepath}")
        print(f"  - Iteración: {self.state.current_iteration}")
        print(f"  - Mejor pérdida: {self.state.best_loss:.6f}")
        print(f"  - Razón de parada: {self.state.stop_reason or 'N/A'}")
        
        return str(filepath)
    
    def load_checkpoint(self, filepath: str) -> Dict[str, Any]:
        """
        Carga un punto de control del entrenamiento.
        
        Args:
            filepath: Ruta del archivo de checkpoint
        
        Returns:
            Diccionario con model_state y optimizer_state
        """
        with open(filepath, "rb") as f:
            checkpoint = pickle.load(f)
        
        self.state = TrainingState.from_dict(checkpoint["training_state"])
        
        print(f"[TenMiNaTor] Checkpoint cargado: {filepath}")
        print(f"  - Reanudando desde iteración: {self.state.current_iteration}")
        print(f"  - Mejor pérdida anterior: {self.state.best_loss:.6f}")
        
        return {
            "model_state": checkpoint.get("model_state"),
            "optimizer_state": checkpoint.get("optimizer_state")
        }
    
    def get_summary(self) -> str:
        """
        Retorna un resumen del estado del entrenamiento.
        """
        return f"""
========================================
TenMiNaTor - Resumen de Entrenamiento
========================================
Iteraciones completadas: {self.state.current_iteration}/{self.config.max_iterations}
Mejor pérdida: {self.state.best_loss:.6f}
Iteraciones sin mejora: {self.state.iterations_without_improvement}/{self.config.early_stop_patience}
Tokens procesados: {self.state.total_tokens_processed}
Razón de parada: {self.state.stop_reason or 'En progreso'}
Inicio: {self.state.start_time}
Última actualización: {self.state.last_update_time}
========================================
"""

# --- Funciones de Conveniencia ---

def create_training_controller(
    max_iterations: int = 69,
    early_stop: bool = True,
    early_stop_patience: int = 12,
    max_tokens: Optional[int] = None,
    token_limit_iterations: int = 12,
    checkpoint_dir: str = "./checkpoints",
    resume_from: Optional[str] = None
) -> TrainingController:
    """
    Crea un controlador de entrenamiento con las opciones especificadas.
    
    Args:
        max_iterations: Máximo de iteraciones (por defecto 69)
        early_stop: Activar Early Stopping [NEW]
        early_stop_patience: Iteraciones sin mejora antes de parar (por defecto 12) [NEW]
        max_tokens: Límite de tokens (None = sin límite)
        token_limit_iterations: Máximo de iteraciones con límite de tokens
        checkpoint_dir: Directorio para checkpoints
        resume_from: Ruta de checkpoint para reanudar
    
    Returns:
        TrainingController configurado
    """
    config = TrainingConfig(
        max_iterations=max_iterations,
        early_stop_patience=early_stop_patience if early_stop else max_iterations,
        max_tokens=max_tokens,
        token_limit_iterations=token_limit_iterations,
        checkpoint_dir=checkpoint_dir,
        resume_from_checkpoint=resume_from
    )
    
    return TrainingController(config)

# --- Ejemplo de Uso ---

def example_training_loop():
    """
    Ejemplo de bucle de entrenamiento con control de iteraciones.
    """
    print("=== Ejemplo de Bucle de Entrenamiento ===")
    
    # Crear controlador con Early Stopping [NEW]
    controller = create_training_controller(
        max_iterations=69,
        early_stop=True,
        early_stop_patience=12,  # [NEW] Salto tras 12 iteraciones sin mejora
        max_tokens=10,  # Límite de 10 tokens
        token_limit_iterations=12
    )
    
    # Simular entrenamiento
    import random
    random.seed(42)
    
    while controller.should_continue():
        # Simular pérdida (con tendencia a mejorar al principio, luego estancarse)
        base_loss = 1.0 / (controller.state.current_iteration + 1)
        noise = random.uniform(-0.1, 0.1)
        loss = base_loss + noise + 0.1  # Añadir offset para simular estancamiento
        
        # Simular tokens procesados
        tokens = random.randint(1, 3)
        
        controller.update(loss, tokens_processed=tokens)
    
    print(controller.get_summary())
    
    # Guardar checkpoint
    model_state = {"weights": [1.0, 2.0, 3.0]}
    controller.save_checkpoint(model_state)

if __name__ == "__main__":
    example_training_loop()

