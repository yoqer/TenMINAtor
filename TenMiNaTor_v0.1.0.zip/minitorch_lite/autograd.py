import numpy as np
from collections import deque
from . import backends as B

class Function:
    """
    Clase base para todas las operaciones de autograd.
    """

    @staticmethod
    def forward(ctx, *args, **kwargs):
        raise NotImplementedError

    @staticmethod
    def backward(ctx, grad_output):
        raise NotImplementedError

    @classmethod
    def apply(cls, *args, **kwargs):
        ctx = Context()

        # 1. Extraer los datos (NumPy arrays) para el forward
        forward_args = []
        for t in args:
            if hasattr(t, 'data'): # Check if it's a Tensor-like object
                forward_args.append(t.data)
            else:
                forward_args.append(t)

        # Ejecuta la función forward con argumentos y kwargs
        output_data = cls.forward(ctx, *forward_args, **kwargs)

        # 2. Guardar los argumentos originales (tensores) para el backward
        ctx.save_for_backward(*args)

        # 3. Preparar la función de gradiente si es necesario
        requires_grad = any(getattr(t, 'requires_grad', False) for t in args)
        grad_fn = None
        if requires_grad:
            ctx.parents = args
            grad_fn = (cls, ctx)

        return output_data, grad_fn

class Context:
    def __init__(self):
        self.parents = []
        self.saved_tensors = []

    def save_for_backward(self, *args):
        self.saved_tensors = args

# --- Implementación de Operaciones Básicas ---

class MatMul(Function):
    @staticmethod
    def forward(ctx, a, b):
        return B.matmul(a, b)

    @staticmethod
    def backward(ctx, grad_output):
        a, b = ctx.saved_tensors
        grad_a = B.matmul(grad_output, B.transpose(b.data))
        grad_b = B.matmul(B.transpose(a.data), grad_output)
        return grad_a, grad_b

class Add(Function):
    @staticmethod
    def forward(ctx, a, b):
        return B.add(a, b)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output, grad_output

class Mul(Function):
    @staticmethod
    def forward(ctx, a, b):
        return B.multiply(a, b)

    @staticmethod
    def backward(ctx, grad_output):
        a, b = ctx.saved_tensors
        grad_a = B.multiply(grad_output, b.data)
        grad_b = B.multiply(grad_output, a.data)
        return grad_a, grad_b

class Sum(Function):
    @staticmethod
    def forward(ctx, a, axis=None, keepdims=False):
        ctx.original_shape = a.shape
        ctx.axis = axis
        return B.sum_array(a, axis=axis, keepdims=keepdims)

    @staticmethod
    def backward(ctx, grad_output):
        original_shape = ctx.original_shape
        axis = ctx.axis
        
        if axis is None:
            grad_a = B.full(original_shape, float(grad_output))
        else:
            # Expand dims to match original shape for broadcasting
            grad_a = np.expand_dims(grad_output, axis=axis)
            grad_a = np.broadcast_to(grad_a, original_shape)

        return (grad_a,)

# --- Implementación de la Retropropagación (Backward) ---

def backward(tensor):
    if not tensor.requires_grad:
        raise RuntimeError("El tensor no requiere gradiente.")

    if tensor.grad is None:
        tensor.grad = B.ones_like(tensor.data)

    q = deque()
    visited = set()

    def build_topo(t):
        if id(t) not in visited:
            visited.add(id(t))
            if t.grad_fn:
                cls, ctx = t.grad_fn
                for parent in ctx.parents:
                    if parent.requires_grad:
                        build_topo(parent)
            q.appendleft(t)

    build_topo(tensor)

    for t in q:
        if t.grad_fn:
            cls, ctx = t.grad_fn
            input_grads = cls.backward(ctx, t.grad)

            if not isinstance(input_grads, tuple):
                input_grads = (input_grads,)

            grad_idx = 0
            for parent in ctx.parents:
                if parent.requires_grad:
                    if grad_idx < len(input_grads):
                        grad = input_grads[grad_idx]
                        if parent.grad is None:
                            parent.grad = grad
                        else:
                            parent.grad = B.add(parent.grad, grad)
                        grad_idx += 1
