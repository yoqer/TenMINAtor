
from pydantic import BaseModel, Field
from typing import Optional

class ModelConfig(BaseModel):
    vocab_size: int = Field(1000, description="Tamaño del vocabulario")
    d_model: int = Field(128, description="Dimensión del modelo")
    nhead: int = Field(4, description="Número de cabezas de atención")
    num_layers: int = Field(2, description="Número de capas del Transformer")
    d_ff: int = Field(256, description="Dimensión de la capa feed-forward")

class TrainingConfig(BaseModel):
    lr: float = Field(0.001, description="Tasa de aprendizaje")
    epochs: int = Field(5, description="Número de épocas")
    batch_size: int = Field(8, description="Tamaño del lote")
    early_stop_patience: int = Field(12, description="Paciencia para early stopping")

class FullConfig(BaseModel):
    model: ModelConfig = ModelConfig()
    training: TrainingConfig = TrainingConfig()

    @classmethod
    def from_json(cls, filepath: str) -> "FullConfig":
        with open(filepath, "r") as f:
            return cls.model_validate_json(f.read())

# --- Ejemplo de Uso ---

def example_config_usage():
    """Ejemplo de uso de la configuración con Pydantic."""
    # Crear configuración por defecto
    config = FullConfig()
    print("--- Configuración con Pydantic ---")
    print("Configuración por defecto:")
    print(config.model_dump_json(indent=2))

    # Guardar configuración a un archivo
    with open("config.json", "w") as f:
        f.write(config.model_dump_json(indent=2))

    # Cargar configuración desde un archivo
    loaded_config = FullConfig.from_json("config.json")
    print("\nConfiguración cargada:")
    print(loaded_config.model_dump_json(indent=2))

if __name__ == "__main__":
    example_config_usage()

