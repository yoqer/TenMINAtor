import numpy as np
from typing import Optional, List, Dict, Any
from .tensor import Tensor
from . import backends as B

class Module:
    """
    Clase base para todos los módulos de red neuronal.
    """
    
    def __init__(self):
        self._parameters: Dict[str, Tensor] = {}
        self._modules: Dict[str, 'Module'] = {}
        self._training = True
    
    def forward(self, x: Tensor) -> Tensor:
        raise NotImplementedError
    
    def __call__(self, x: Tensor) -> Tensor:
        return self.forward(x)
    
    def parameters(self) -> List[Tensor]:
        """Retorna todos los parámetros del módulo."""
        params = list(self._parameters.values())
        for module in self._modules.values():
            params.extend(module.parameters())
        return params
    
    def named_parameters(self) -> Dict[str, Tensor]:
        """Retorna todos los parámetros con sus nombres."""
        params = dict(self._parameters)
        for name, module in self._modules.items():
            for param_name, param in module.named_parameters().items():
                params[f"{name}.{param_name}"] = param
        return params

    def layer_gradients(self) -> Dict[str, np.ndarray]:
        """Retorna los gradientes de los parámetros de esta capa."""
        grads = {}
        for name, param in self._parameters.items():
            if param.grad is not None:
                grads[name] = param.grad
        return grads

    def train(self, mode: bool = True):
        self._training = mode
        for module in self._modules.values():
            module.train(mode)
        return self
    
    def eval(self):
        return self.train(False)
    
    def state_dict(self) -> Dict[str, np.ndarray]:
        state = {}
        for name, param in self.named_parameters().items():
            state[name] = param.data.copy()
        return state
    
    def load_state_dict(self, state_dict: Dict[str, np.ndarray]):
        for name, param in self.named_parameters().items():
            if name in state_dict:
                param.data = state_dict[name].copy()
    
    def zero_grad(self):
        for param in self.parameters():
            param.zero_grad()

class Parameter(Tensor):
    def __init__(self, data, requires_grad=True):
        super().__init__(data, requires_grad=requires_grad)

class Linear(Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        scale = np.sqrt(2.0 / (in_features + out_features))
        weight_data = np.random.randn(out_features, in_features).astype(np.float32) * scale
        self._parameters['weight'] = Parameter(weight_data)
        if bias:
            bias_data = np.zeros(out_features, dtype=np.float32)
            self._parameters['bias'] = Parameter(bias_data)
        self.use_bias = bias
    
    def forward(self, x: Tensor) -> Tensor:
        weight = self._parameters['weight']
        output = x @ Tensor(weight.data.T, requires_grad=weight.requires_grad)
        if self.use_bias:
            bias = self._parameters['bias']
            output = output + bias
        return output

# ... (otras capas y funciones se mantienen igual)

class MSELoss(Module):
    def forward(self, y_pred: Tensor, y_true: Tensor) -> Tensor:
        return ((y_pred - y_true) ** 2).mean()
