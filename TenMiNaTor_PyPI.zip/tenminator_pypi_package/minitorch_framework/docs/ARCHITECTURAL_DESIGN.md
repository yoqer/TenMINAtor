# Diseño Arquitectónico del Framework MiniTorch Avanzado

Este documento detalla el diseño arquitectónico para integrar las funcionalidades avanzadas solicitadas en el Framework MiniTorch, construyendo sobre la base de MiniTorch Lite. El objetivo es crear un sistema de Deep Learning robusto, flexible y eficiente, capaz de manejar tareas complejas de entrenamiento e inferencia.

## 1. Principios de Diseño General

El desarrollo de este framework se rige por varios principios fundamentales que aseguran su escalabilidad, mantenibilidad y rendimiento. La **modularidad** es clave, con cada funcionalidad principal encapsulada en un módulo independiente para facilitar la extensibilidad y el mantenimiento. Se mantendrá y expandirá la **flexibilidad de backend**, permitiendo el uso de diferentes implementaciones de bajo nivel (NumPy, JAX, Numba, CuPy) para optimizar las operaciones. El framework ofrecerá una **abstracción** significativa, proporcionando APIs de alto nivel que ocultan la complejidad de las implementaciones subyacentes, lo que simplifica su uso. La **eficiencia** es una prioridad, con optimizaciones dirigidas a un rendimiento ligero tanto en el entrenamiento como en la inferencia. Finalmente, la **interactividad** se logrará mediante una interfaz de usuario de consola que permitirá el control del entrenamiento en tiempo real, ofreciendo una experiencia de usuario dinámica y responsiva.

## 2. Integración de Nested Learning [1]

El concepto de Nested Learning (NL) propone representar los modelos de Machine Learning y sus procedimientos de entrenamiento como un conjunto de problemas de optimización anidados, multinivel y/o paralelos, cada uno con su propio 
flujo de contexto. Esta perspectiva sugiere que los optimizadores existentes, como Adam o SGD con Momentum, pueden ser vistos como módulos de memoria asociativa que comprimen la información de los gradientes [1].

La integración de Nested Learning en MiniTorch implicará modificaciones fundamentales en la forma en que se define y se entrena un modelo. El módulo `minitorch_lite/autograd.py` se adaptará para permitir la definición de grafos de cómputo multinivel, donde cada nivel representa un problema de optimización anidado. Esto significa que las funciones de `forward` y `backward` no solo propagarán valores y gradientes, sino también información de contexto relevante para los niveles anidados. El módulo `minitorch_lite/optim.py` se extenderá para soportar optimizadores más expresivos, capaces de gestionar múltiples flujos de gradientes y estados de memoria asociados a diferentes niveles de anidamiento. Esto permitirá la implementación de optimizadores que aprenden sus propias reglas de actualización o que tienen una "memoria profunda" para la compresión de gradientes, como se sugiere en el paper de NL [1].

## 3. Integración de Absolute Zero Reasoner (AZR) [2] [3]

El Absolute Zero Reasoner (AZR) introduce un paradigma de auto-juego donde un modelo es capaz de proponer tareas, resolverlas y aprender de sus propias interacciones sin depender de datos externos curados por humanos. Este enfoque se basa en un sistema de retroalimentación verificable, a menudo a través de un ejecutor de código, que valida las soluciones y guía el aprendizaje [2].

Para integrar AZR, se creará un nuevo módulo, `minitorch_framework/reasoning/az_reasoner.py`, que encapsulará la lógica central. Este módulo incluirá un `TaskProposer` para generar tareas de razonamiento, un `TaskSolver` que utilizará el `TransformerRLM` existente para intentar resolverlas, y un `CodeExecutor` que simulará la ejecución de código para validar las soluciones y proporcionar retroalimentación. La evaluación del aprendizaje se realizará mediante un `LearnabilityReward`, que medirá el potencial de mejora del modelo al resolver una tarea, y un `SolutionReward`, que evaluará la corrección de la solución. El módulo `minitorch_framework/rl/reinforcement_learning.py` se extenderá para procesar estas recompensas y guiar el entrenamiento del `TransformerRLM` en el contexto de auto-juego del AZR.

## 4. Gradientes por Capas [4]

La capacidad de manipular gradientes a nivel de capas individuales es fundamental para técnicas avanzadas de optimización y aprendizaje por refuerzo. Permite un control granular sobre cómo se actualizan los parámetros del modelo, facilitando estrategias como el congelamiento de capas o la aplicación de diferentes tasas de aprendizaje.

El módulo `minitorch_lite/autograd.py` se modificará para que la función `backward` pueda devolver gradientes específicos para cada tensor de entrada, en lugar de solo un gradiente agregado. Esto se logrará mediante la introducción de un mecanismo para registrar y acceder a los gradientes de cada capa durante la retropropagación. Las clases de capas en `minitorch_lite/nn.py` expondrán propiedades para acceder directamente a los gradientes de sus pesos y sesgos (ej., `layer.weight.grad`, `layer.bias.grad`). Además, se considerará la implementación de un `LayerGradientHook` que permitirá a los usuarios registrar funciones personalizadas para interceptar y modificar gradientes en capas específicas. Los optimizadores en `minitorch_lite/optim.py` se adaptarán para utilizar esta información de gradientes por capa, permitiendo esquemas de actualización más sofisticados.

## 5. Steering de Modelos (RL sobre Capas Específicas) [5]

El steering de modelos, o la capacidad de dirigir el aprendizaje por refuerzo hacia capas específicas, es una extensión directa de la manipulación de gradientes por capas. Permite influir en el comportamiento de sub-módulos particulares del modelo, lo cual es crucial para corregir errores focalizados o adaptar el modelo a nuevas tareas de manera eficiente.

El módulo `minitorch_framework/rl/reinforcement_learning.py` se extenderá para permitir la especificación de `target_layers` o `layer_mask` al aplicar señales de recompensa. Esto significa que la función de pérdida de RL se calculará de tal manera que solo afecte los gradientes de las capas designadas. Los modelos en `minitorch_framework/models/base_model.py` (o un mecanismo similar) incluirán métodos para "congelar" o "descongelar" capas, asegurando que solo los parámetros de las capas seleccionadas sean actualizados por el optimizador de RL. Esta funcionalidad, combinada con los gradientes por capas, proporcionará un control sin precedentes sobre el proceso de afinamiento del modelo.

## 6. Tokenización Flexible [6]

La tokenización tradicional puede introducir sesgos y limitaciones en el procesamiento del lenguaje. La tokenización flexible, que permite operar a nivel de carácter o byte, ofrece una mayor granularidad y puede ser más robusta frente a idiomas con morfología compleja o datos ruidosos.

Se introducirá un nuevo módulo, `minitorch_framework/data/tokenizer.py`, que contendrá una clase `FlexibleTokenizer`. Esta clase soportará múltiples modos de tokenización, incluyendo `Word-level` (tradicional), `Char-level` (procesamiento a nivel de carácter) y `Byte-level` (procesamiento a nivel de byte). El `TransformerRLM` en `minitorch_framework/models/transformer_rlm.py` se adaptará para aceptar entradas tokenizadas de forma flexible, ajustando sus capas de embedding y su lógica de procesamiento para operar con estas diferentes representaciones. Esto permitirá al usuario elegir el nivel de granularidad más adecuado para su tarea, optimizando tanto el rendimiento como la eficiencia.

## 7. Estructura Loop para Modelos [7]

La eficiencia en el entrenamiento y la inferencia de modelos, especialmente en arquitecturas complejas como Transformers y LLMs, depende en gran medida de la implementación de bucles de procesamiento optimizados. Una estructura de bucle bien diseñada puede mejorar significativamente la ligereza y la capacidad de interrupción/reanudación de los procesos.

Se crearán dos nuevos módulos: `minitorch_framework/training/training_loop.py` y `minitorch_framework/inference/inference_loop.py`. La clase `TrainingLoop` encapsulará el ciclo de entrenamiento, permitiendo la configuración de épocas, pasos y la integración con el sistema de control `10x12`. Soportará iteradores de datos eficientes y la carga de datos en lotes. La clase `InferenceLoop` estará optimizada para la inferencia, con soporte para `vLLM` y `KV-Cache`, y manejará la generación de texto autoregresiva y la decodificación eficiente. Ambos bucles estarán diseñados para ser ligeros y permitir la pausa y reanudación sin pérdida de estado.

## 8. Sistema de Memoria para Modelos [8]

La capacidad de los modelos para retener y recuperar información a largo plazo es crucial para el aprendizaje continuo y para superar las limitaciones de la ventana de contexto. Un sistema de memoria robusto permite a los modelos acceder a conocimientos pasados y utilizarlos en nuevas situaciones.

Se implementará un nuevo módulo, `minitorch_framework/memory/memory_system.py`, que contendrá diferentes tipos de memoria. Esto incluirá una `EpisodicMemory` para almacenar experiencias pasadas (ej., pares de entrada/salida, estados, recompensas), una `SemanticMemory` para almacenar conocimientos generales o hechos en un formato recuperable (ej., embeddings de conocimiento, grafos de conocimiento), y una `WorkingMemory` para gestionar la información dentro de la ventana de contexto actual del modelo. El `TransformerRLM` se integrará con este `MemorySystem`, permitiendo al modelo consultar la memoria para obtener información relevante antes de generar una respuesta y escribir nueva información en la memoria durante el entrenamiento o la inferencia, facilitando así el aprendizaje continuo y el razonamiento a largo plazo.

## 9. Integración con Herramientas Externas (Unsloth, LangChain, LangGraph)

La interoperabilidad con herramientas populares del ecosistema de LLMs y RL es esencial para la adopción y la utilidad del framework. Proporcionar adaptadores permite a los usuarios aprovechar las funcionalidades de estas librerías en combinación con los modelos de MiniTorch.

Se creará un nuevo módulo, `minitorch_framework/integrations/external_tools.py`, que contendrá adaptadores para `Unsloth`, `LangChain` y `LangGraph`. El `UnslothAdapter` optimizará el entrenamiento y la inferencia de modelos grandes utilizando las optimizaciones de Unsloth. El `LangChainAdapter` permitirá integrar modelos de MiniTorch en cadenas de LangChain, facilitando la construcción de agentes complejos. El `LangGraphAdapter` permitirá definir y ejecutar grafos de computación complejos con modelos de MiniTorch, apoyando el desarrollo de agentes multi-paso y sistemas de razonamiento. Los modelos de MiniTorch se diseñarán para ser compatibles con estas integraciones, exponiendo métodos y propiedades que puedan ser utilizados por los adaptadores.

## 10. Sistema de Control de Entrenamiento '10x12' y UI de Consola

El sistema de control de entrenamiento '10x12' es una característica clave para la robustez y la eficiencia, permitiendo una gestión interactiva del entrenamiento con segmentación de datos, limitación de repeticiones, pausa, reanudación y detención con guardado de estado. Todo esto se manejará a través de una interfaz de usuario de consola interactiva.

El módulo `minitorch_framework/training/training_controller.py` se actualizará para incluir la lógica de **segmentación de datos** en "paquetes de 10" (ej., 10 palabras o identificadores) para un procesamiento ligero. Se implementará un **límite de repeticiones '12'** para cadenas de entrenamiento similares, deteniendo el entrenamiento de una cadena si se excede este límite. La **UI de consola interactiva** mostrará el progreso del entrenamiento y ofrecerá opciones mediante entrada de teclado para: **Detener y Guardar** (finaliza el entrenamiento y guarda el estado completo para reanudar), **Pausar y Continuar** (guarda el estado para reanudar en la misma sesión o en un reinicio), **Saltar Proceso (Continue)** (salta la iteración actual y continúa), **Reiniciar Entrenamiento** (desde cero o un punto de control), y **Guardar Modelo** (sin detener el entrenamiento). Al detenerse, se registrará el estado del gradiente (valor, dirección, desviación) para informar al usuario y permitir una reanudación inteligente. La "ventana pop-up" se simulará con mensajes detallados en la consola, incluyendo un mensaje de finalización con información sobre el estado del gradiente y una opción de "Más Detalles" para información técnica. Un nuevo módulo, `minitorch_framework/data/data_processor.py`, manejará la segmentación de datos de texto y asegurará un orden consistente en el entrenamiento de los paquetes.

## 11. Preparación de Pruebas Específicas para el Sistema '10x12'

Para validar la funcionalidad del sistema de control de entrenamiento '10x12', se desarrollará un script de prueba específico que verifique la segmentación de datos, el límite de repeticiones y la interacción de la UI de consola.

Se creará un nuevo módulo, `minitorch_framework/tests/test_10x12_system.py`, que utilizará un conjunto de datos mínimo (ej., "El perro corre") para verificar la segmentación de datos en paquetes de 10 palabras y que el límite de 12 repeticiones de cadenas similares se respeta. También probará las opciones de la UI de consola (detener, pausar, saltar) y verificará que el estado del modelo se guarda/restaura correctamente. Se generará una cadena de 13 palabras autogeneradas para probar el límite de 12 repeticiones independientemente de la alineación del gradiente, asegurando que el sistema de control de entrenamiento funcione como se espera incluso en escenarios donde el gradiente no se alinea perfectamente.

## 12. Actualización de vLLM y Transformer RLM con Nuevas Capacidades

Las arquitecturas existentes de `vLLM` y `TransformerRLM` se actualizarán para integrar las nuevas funcionalidades de Nested Learning, el Sistema de Memoria y la Tokenización Flexible, mejorando su rendimiento y capacidades.

El `TransformerRLM` en `minitorch_framework/models/transformer_rlm.py` se adaptará para utilizar el `MemorySystem` para la recuperación de contexto y la actualización de memoria, y se integrará con el `FlexibleTokenizer` para manejar diferentes modos de tokenización. Además, se ajustará para soportar gradientes por capas y el steering de modelos, permitiendo un control más preciso sobre su entrenamiento. El `vLLM` en `minitorch_framework/vllm/relational_vllm.py` se asegurará de que sus optimizaciones (KV-Cache, Continuous Batching) sean compatibles con las nuevas funcionalidades y se explorará cómo el `MemorySystem` puede mejorar la eficiencia y la calidad de la inferencia en `vLLM`, permitiendo una generación de texto más coherente y contextualmente rica.

## 13. Creación de Documentación Completa y Ejemplos End-to-End

Una documentación exhaustiva y ejemplos prácticos son esenciales para que los usuarios puedan comprender y utilizar eficazmente todas las nuevas funcionalidades del framework.

El `MANUAL_DE_USO.md` en `minitorch_framework/docs/` se actualizará con secciones detalladas sobre Nested Learning, el uso del Absolute Zero Reasoner, la manipulación de gradientes por capas, el steering de modelos, la configuración de tokenización flexible, la integración con el `MemorySystem`, y el uso del sistema de control de entrenamiento '10x12' y la UI de consola. Se añadirán nuevos scripts de ejemplo en `minitorch_framework/examples/` que demuestren cada una de las funcionalidades avanzadas, proporcionando guías paso a paso y casos de uso prácticos para facilitar la adopción y experimentación por parte de los usuarios.

## 14. Empaquetado del Framework y Entrega de Resultados

Finalmente, se generarán los archivos ZIP solicitados para la distribución del framework y sus componentes de prueba.

El archivo `setup.py` se actualizará para incluir todos los nuevos módulos y dependencias del framework. Se crearán dos archivos ZIP: uno contendrá el framework completo (`minitorch_framework.zip`) y el otro incluirá el script de prueba específico para el sistema '10x12' (`minitorch_10x12_test.zip`), junto con las instrucciones para su ejecución directa. Esto permitirá al usuario verificar la funcionalidad del sistema de control de entrenamiento de manera independiente y eficiente, tal como se ha solicitado.
