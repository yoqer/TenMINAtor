from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="tenminator",
    version="0.1.0",
    author="TenMiNaTor Team",
    author_email="support@tenminator.dev",
    description="Framework de Deep Learning ultraligero inspirado en PyTorch para dispositivos con almacenamiento limitado",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tu-usuario/tenminator",
    packages=find_packages(exclude=["tests", "examples", "docs"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
    ],
    extras_require={
        "jax": [
            "jax>=0.4.0",
            "jaxlib>=0.4.0",
        ],
        "cupy": [
            "cupy>=11.0.0",
        ],
        "numba": [
            "numba>=0.56.0",
        ],
        "database": [
            "sqlalchemy>=2.0.0",
            "pymongo>=4.0.0",
            "firebase-admin>=6.0.0",
        ],
        "web": [
            "beautifulsoup4>=4.11.0",
            "requests>=2.28.0",
        ],
        "graph": [
            "networkx>=3.0",
        ],
        "validation": [
            "pydantic>=2.0.0",
        ],
        "dataframe": [
            "pandas>=2.0.0",
        ],
        "all": [
            "jax>=0.4.0",
            "jaxlib>=0.4.0",
            "cupy>=11.0.0",
            "numba>=0.56.0",
            "sqlalchemy>=2.0.0",
            "pymongo>=4.0.0",
            "firebase-admin>=6.0.0",
            "beautifulsoup4>=4.11.0",
            "requests>=2.28.0",
            "networkx>=3.0",
            "pydantic>=2.0.0",
            "pandas>=2.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "tenminator=tenminator.cli:main",
        ],
    },
    keywords="deep-learning machine-learning pytorch tensorflow neural-networks autograd lightweight",
    project_urls={
        "Bug Reports": "https://github.com/tu-usuario/tenminator/issues",
        "Documentation": "https://tenminator.dev/docs",
        "Source": "https://github.com/tu-usuario/tenminator",
    },
)
