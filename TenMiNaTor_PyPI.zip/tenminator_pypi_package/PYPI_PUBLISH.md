# Instrucciones para Publicar TenMiNaTor en PyPI

Esta guía te muestra cómo publicar el paquete TenMiNaTor en PyPI para que otros puedan instalarlo con `pip install tenminator`.

---

## 📋 Requisitos Previos

1. **Cuenta en PyPI**: Crea una cuenta en [https://pypi.org/account/register/](https://pypi.org/account/register/)
2. **Cuenta en TestPyPI** (opcional, para pruebas): [https://test.pypi.org/account/register/](https://test.pypi.org/account/register/)
3. **Instalar herramientas de publicación**:

```bash
pip install --upgrade pip setuptools wheel twine
```

---

## 🚀 Pasos para Publicar

### 1. Preparar el Paquete

Asegúrate de estar en el directorio del paquete:

```bash
cd /home/ubuntu/tenminator_pypi_package
```

### 2. Construir el Paquete

Genera los archivos de distribución:

```bash
python setup_pypi.py sdist bdist_wheel
```

Esto creará dos archivos en el directorio `dist/`:
- `tenminator-0.1.0.tar.gz` (código fuente)
- `tenminator-0.1.0-py3-none-any.whl` (wheel)

### 3. Verificar el Paquete

Verifica que el paquete esté correctamente formado:

```bash
twine check dist/*
```

### 4. Publicar en TestPyPI (Recomendado para Pruebas)

Primero, prueba en TestPyPI:

```bash
twine upload --repository testpypi dist/*
```

Te pedirá tu usuario y contraseña de TestPyPI.

**Probar la instalación desde TestPyPI:**

```bash
pip install --index-url https://test.pypi.org/simple/ tenminator
```

### 5. Publicar en PyPI (Producción)

Una vez que hayas verificado que todo funciona correctamente:

```bash
twine upload dist/*
```

Te pedirá tu usuario y contraseña de PyPI.

---

## 🔐 Usar Token de API (Recomendado)

En lugar de usar usuario/contraseña, es más seguro usar un token de API:

### Crear Token de API

1. Ve a [https://pypi.org/manage/account/token/](https://pypi.org/manage/account/token/)
2. Crea un nuevo token con alcance para el proyecto `tenminator`
3. Copia el token (empieza con `pypi-`)

### Configurar Token

Crea o edita el archivo `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-TU_TOKEN_AQUI

[testpypi]
username = __token__
password = pypi-TU_TOKEN_DE_TEST_AQUI
```

Ahora puedes publicar sin ingresar credenciales:

```bash
twine upload dist/*
```

---

## 📦 Actualizar el Paquete

Para publicar una nueva versión:

1. **Actualizar versión** en `setup_pypi.py`:
   ```python
   version="0.1.1",  # Incrementar versión
   ```

2. **Limpiar distribuciones antiguas**:
   ```bash
   rm -rf dist/ build/ *.egg-info
   ```

3. **Reconstruir y publicar**:
   ```bash
   python setup_pypi.py sdist bdist_wheel
   twine upload dist/*
   ```

---

## ✅ Verificar Publicación

Después de publicar, verifica:

1. **En PyPI**: [https://pypi.org/project/tenminator/](https://pypi.org/project/tenminator/)
2. **Instalación**:
   ```bash
   pip install tenminator
   ```
3. **Importación**:
   ```python
   from tenminator import Tensor
   print(Tensor([1, 2, 3]))
   ```

---

## 🔧 Comandos Rápidos

```bash
# Construir paquete
python setup_pypi.py sdist bdist_wheel

# Verificar paquete
twine check dist/*

# Publicar en TestPyPI
twine upload --repository testpypi dist/*

# Publicar en PyPI
twine upload dist/*

# Limpiar archivos de construcción
rm -rf dist/ build/ *.egg-info __pycache__
```

---

## 📝 Checklist Pre-Publicación

- [ ] Versión actualizada en `setup_pypi.py`
- [ ] README.md completo y actualizado
- [ ] Todas las dependencias listadas correctamente
- [ ] Licencia incluida (LICENSE file)
- [ ] Tests pasando (si aplica)
- [ ] MANIFEST.in incluye todos los archivos necesarios
- [ ] Changelog actualizado (si aplica)
- [ ] Documentación actualizada

---

## 🐛 Solución de Problemas

### Error: "File already exists"

Si intentas subir una versión que ya existe:
```bash
# Incrementa la versión en setup_pypi.py y reconstruye
python setup_pypi.py sdist bdist_wheel
twine upload dist/*
```

### Error: "Invalid distribution"

Verifica la estructura del paquete:
```bash
python setup_pypi.py check
twine check dist/*
```

### Error: "Authentication failed"

Verifica tus credenciales o token:
```bash
# Usa --verbose para más información
twine upload --verbose dist/*
```

---

## 📚 Recursos Adicionales

- [Guía oficial de PyPI](https://packaging.python.org/tutorials/packaging-projects/)
- [Documentación de Twine](https://twine.readthedocs.io/)
- [Guía de setuptools](https://setuptools.pypa.io/)

---

## 🎉 ¡Listo!

Una vez publicado, los usuarios podrán instalar TenMiNaTor con:

```bash
pip install tenminator
```

Y usar el framework:

```python
from tenminator import Tensor
from tenminator.nn import Linear, ReLU
from tenminator.optim import Adam

# ¡A entrenar modelos!
```

---

**¡Felicidades por publicar tu paquete en PyPI!** 🚀
